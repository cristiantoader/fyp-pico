package marf.Storage.Loaders;

import marf.Storage.*;
import marf.util.*;

import java.io.*;

/**
 * Not Implemented
 */
public class ULAWLoader extends SampleLoader
{
	/**
	 * ULAWLoader Constructor
	 */
	public ULAWLoader()
	{
	}

	/**
	 * Not Implemented
	 */
	public Sample loadSample(File poFile) throws Exception
	{
		throw new NotImplementedException("ULAWLoader.loadSample()");
	}

	/**
	 * Not Implemented
	 */
	public final int readAudioData(double[] pSample) throws Exception
	{
		throw new NotImplementedException("ULAWLoader.readAudioData()");
	}

	/**
	 * Not Implemented
	 */
	public final int writeAudioData(final double[] pSample, final int nbrData) throws Exception
	{
		throw new NotImplementedException("ULAWLoader.writeAudioData()");
	}

	/**
	 * Not Implemented
	 */
	public void saveSample(File poFile) throws Exception
	{
		throw new NotImplementedException("ULAWLoader.saveSample()");
	}
}

// EOF
