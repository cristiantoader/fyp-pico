package marf.Stats;

import marf.util.*;

/**
 * Not Implemented
 */
public class StatsCollector
{
	/*
	 * Ideally we'd want to measure
	 * how long it takes for a particular module to do the thing.
	 * How long it takes to run whole pipeline.
	 * How many features
	 * Amount of noise and silence removed
	 * ...
	 */

	public StatsCollector()
	{
		throw new NotImplementedException("StatsCollector.StatsCollector()");
	}
}

// EOF
